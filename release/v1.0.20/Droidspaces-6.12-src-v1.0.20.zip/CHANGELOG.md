# 变更记录

## v1.0.20 (2026-10-28)

只改外围，**内核模块（ko）未改动**，md5 与 v1.0.19 完全相同：
`15fc08cbd67c06c3aa079bedd75b51bc`

- **WebUI**：真 userns 状态改为按容器进程的真实 `uid_map` 判定。
  `0 0 4294967295`（宿主恒等全映射）= 未生效，不再拿模块自报的 `real=1` 当"已生效"。
- **WebUI**：探针文案 `18/18 · 真映射` → `18/18 · 钩子已挂`，避免暗示隔离成立。
- **WebUI**：容器不在 user namespace 时禁用「转换容器属主」，`doRelabel()` 里再拦一次。
- **WebUI**：移除"自动补写 `real_userns` 意图文件并提示已生效"的逻辑。
- **userns.sh**：`relabel` 增加硬护栏 —— 没有任何进程在 userns 里（`uid_map` 全是
  宿主恒等映射）时拒绝执行，除非显式 `--force`。防止误操作把 rootfs 改成基址后
  容器读不动自己的文件（`su: cannot set groups`）。
- **README**：把"真 userns 可选开启"整节改写为"本机不支持"，列出四条证据链。
- 版本 `v1.0.20-6.12` / `versionCode=10020`。

## v1.0.19 (2026-10-28)

内核模块改动，**修复加载后重启**。

- `unshare` / `clone` 的 `CLONE_NEWUSER` 一律"假成功"：剥掉该 flag，其余命名空间位
  照常交给内核；不再改写 cred 的 `user_ns`，不再伪造 `struct user_namespace`。
- 删除 v1.0.18 引入的 `kernel_clone` / `do_execve` 换凭据路径。
  该路径把伪造的 `user_ns` 塞进 cred，而 `cap_capable()` 里遍历
  `cred->user_ns->parent` 的代码没有 `#ifdef CONFIG_USER_NS`，会读到野指针。
- ko md5：`15fc08cbd67c06c3aa079bedd75b51bc`

## 结论：本机不支持 userns

机型 PMB110 / 内核 6.12.69，`CONFIG_USER_NS` 未编译：

| 证据 | 观测值 |
|---|---|
| `unshare -U true`（模块卸载后） | `Invalid argument`（EINVAL，对应 `#ifndef CONFIG_USER_NS return -EINVAL`） |
| `/proc/config.gz` | `# CONFIG_USER_NS is not set` |
| `/proc/<pid>/ns/user` | 文件不存在 |
| 容器进程 `uid_map` | 恒为 `0 0 4294967295` |

`/proc/sys/user/max_user_namespaces` 有值（62497）是厂商内核的残留节点，
与实际是否编译 userns 无关，不能作为依据。

因此"容器独立 uid / 真 userns 隔离"在本机无法实现，模块不再尝试。
实际隔离只有：mount ns + 独立 rootfs + pid / uts / net ns；
**容器 root 就是宿主 root**，capability 全量。

## 构建

```sh
sh scripts/build-ddkk.sh android16-6.12     # 编译 ko
sh scripts/package-ksu-zip.sh out.zip       # 打 KernelSU 模块包
```

编译产物目录 `droid_lkm/out/` 与 `dist/` 未包含在本源码包内。
