# Droidspaces 内核模块套件（一加 Ace 6 至尊版 / PMB110 / Android 16 / 6.12.69）

用 KernelSU 加载的 6 个 LKM 内核模块 + 完整源码 + 完整构建/部署/验证流程。

当前版本 **v1.0.20-6.12**（`dsm/module.prop`，WebUI 标题右侧直接显示），作者 `ai-luo`。
文档有中文与英文两版：根目录是中文，[`docs/en/`](docs/en/) 是对应的英文版。

目标：**不刷内核**，在原厂 GKI 内核上补齐 Docker / 容器运行时缺失的
`CONFIG_PID_NS` / `CONFIG_IPC_NS` / `CONFIG_SYSVIPC` / `CONFIG_POSIX_MQUEUE` /
`CONFIG_DEVTMPFS`，并额外提供 macvlan 与 IPv6 NAT。

> **关于 `CONFIG_USER_NS`**：这一项**补不了**。本机内核编译时就没打开它
> （`unshare -U true` 返回 EINVAL，`/proc/<pid>/ns/user` 不存在），
> 模块只做了 syscall 层的 id 翻译，**不构成隔离**——容器 root 就是宿主 root。
> 证据与结论见 [`CHANGELOG.md`](CHANGELOG.md) 末尾。

---

## 0. 一分钟速览

| 模块 | 作用 | 状态 |
| --- | --- | --- |
| `droid_lkm.ko` | PID/IPC namespace、System V IPC、POSIX mqueue | ✅ 加载成功 |
| `droid_lkm_vendor.ko` | oplus 厂商兼容（指纹 / 参数修正） | ✅ 加载成功 |
| `droid_lkm_misc.ko` | devtmpfs（硬件访问可用）；user namespace 视图（**本机内核无 `CONFIG_USER_NS`，不生效**） | ✅ 加载成功 |
| `droid_lkm_pids.ko` | `pids` 控制器：显示层（检查项变绿）+ **功能层**（`--pids-limit` 真实拦截 fork），可单独卸载 | ✅ 真机验证通过（DS 检查 40 项全绿，`refused` > 0） |
| `macvlan.ko` | 容器独立局域网 IP（`docker run --net=macvlan`） | ⚠ 控制面可用，数据面受 WiFi 限制 |
| `ip6table_nat.ko` | IPv6 NAT（`docker run --net=nat` 的 IPv6） | ✅ 加载成功，规则可增删 |

实测组合（**唯一验证过的组合**）：

- 机型：一加 Ace 6 至尊版，`PMB110`
- 系统：`17.0.0.101(CNO1C10P02)`
- 内核：`6.12.69-android16-6-g242e1a07f878-ab15865446-4k`

---

## 1. 目录结构

```
.
├── README.md                  本文件
├── BUILD.md                   从源码到 ko 的完整构建流程
├── VERIFY.md                  部署后的完整验证清单（含判定标准）
├── USAGE.md                   使用与排错（WebUI / Docker / 恢复）
├── LICENSE                    GPL-2.0（本项目代码）
├── THIRD-PARTY.md             第三方源码归属与许可证
├── docs/
│   ├── PRINCIPLE.md           实现原理（每个模块到底做了什么）
│   ├── PIDS-ENFORCEMENT.md    pids 功能层：`pids.max` 是怎么造的、fork 怎么被拦
│   ├── BUILD-FOR-OTHERS.md    为别人的手机构建（适配流程）
│   └── en/                    上面几份文档的英文版
├── droid_lkm/                 主模块（droid_lkm / vendor / misc）
│   ├── src/
│   │   ├── main/              PID_NS / IPC_NS / SysV / mqueue / slot
│   │   ├── compat/            厂商兼容、ghost task、ddl 历史表
│   │   ├── hook/              inline hook 封装
│   │   ├── misc/              userns、devtmpfs、xtables 扩展
│   │   ├── pidsmod/           独立的 pids 控制器名上报模块
│   │   └── core/              kallsyms 符号解析、Type-info、caps
│   ├── deps/                  第三方依赖源码快照（可离线构建）
│   ├── mk/                    依赖装配 makefile 片段
│   ├── Makefile               三个主模块的 Kbuild 文件
│   └── deps.lst               第三方依赖及固定版本
├── net_macvlan/               macvlan.ko 源码（7 符号 shim + KallRecon）
├── net_ip6nat/                ip6table_nat.ko 源码（9 符号 shim + KallRecon）
├── scripts/
│   ├── build-ddkk.sh          编译三个主模块（DDK）
│   ├── build-net-ddk.sh       编译 macvlan / ip6table_nat（DDK，必需）
│   ├── fetch-deps.sh          拉取第三方依赖
│   ├── package-ksu-zip.sh     打成 KernelSU 可安装 zip
│   ├── load_macvlan.sh        单模块手动加载
│   └── load_ip6nat.sh         单模块手动加载
├── dsm-pids/                  **只装 pids 的最小包**（单独 Ko + 手动加载，适合只要 --pids-limit）
├── dsm/                       KernelSU 模块本体（即最终安装目录结构）
│   ├── module.prop
│   ├── post-fs-data.sh        守卫 / 开关 / 加载逻辑
│   ├── service.sh             存活守卫
│   ├── uninstall.sh
│   ├── desc.sh                把"已加载 N/6: ..."写回 module.prop 的 description
│   ├── ko/*.ko                6 个预编译模块
│   └── webroot/index.html     三页 WebUI（状态 / 容器 / 日志）
├── prebuilt/                  预编译产物校验和 + 说明（ko 本体在 dsm/ko/）
└── docs/                      实现原理 + 为他人构建指南
```

---

## 2. 五分钟上手

```bash
# 1. 把整个 dsm/ 目录做成 zip，用 KernelSU 刷入（"从压缩包安装"）
#    注意：包内已预置 no_boot，首次安装不会自动加载，手机必然正常开机。

# 2. KernelSU 管理器 → 模块 → Droidspaces → WebUI
#    手动点「加载」。第一次务必手动，不要开自启。

# 3. 确认六个模块都显示「已加载」
su -c 'cat /proc/modules'

# 3.5 模块列表里会直接显示加载了什么（desc.sh 自动维护，不用手动改）
#    KernelSU → 模块 → Droidspaces 的 description 会变成：
#      已加载 4/6: lkm · vendor · misc · pids
#    一个都没加载时显示原本的说明文字。管理器的模块页需要下拉刷新才看得到更新。
#    WebUI 状态页的「模块说明」一行读的是同一个字段。

# 4. 开 Droidspaces，编辑容器，确认「允许沙箱」「硬件访问」能打开

# 5. 进程数限制（需 droid_lkm_pids 已加载，建议 >= 256）
docker run --rm --pids-limit 256 hello-world
su -c 'cat /sys/fs/cgroup/<容器目录>/pids.stats'   # refused > 0 即真的在拦

# 6. 用 10 分钟没事，再回 WebUI 打开「开机自动加载」
```

只要 pids 一个模块的话，用 `dsm-pids/` 这个最小包，见其 `README.txt`。

完整验证见 `VERIFY.md`，完整恢复手段见 `USAGE.md`。

### 给别人用 / 给别人编译

`dsm/ko/*.ko`（预编译产物）**只在 PMB110 / 6.12.69 上验证过**，别人不能直接用。
不同机型或不同内核需要重新编译，完整适配流程见
[`docs/BUILD-FOR-OTHERS.md`](docs/BUILD-FOR-OTHERS.md)，一句话版本：

```bash
# 对方手机内核属于哪个 GKI 版本，就用哪个 DDK target
sh scripts/build-ddkk.sh    android15-6.6     # 例：6.6 内核
sh scripts/build-net-ddk.sh android15-6.6
sh scripts/package-ksu-zip.sh
# 装好后放开机型锁
su -c 'echo "<对方机型代号>" >> /data/adb/modules/Droidspaces/allow_list'
```

**关键约束**：clang 版本必须与目标内核编译时一致（KCFI）。
用系统 clang 18 编的模块 `insmod` 会直接关机。必须用 DDK 镜像。

---

## 3. 硬性限制（务必读）

| 项 | 要求 |
| --- | --- |
| 机型 | `ro.product.*` 含 `PMB110` |
| 内核 | `6.12.69-*` |
| 引导 | KernelSU（非 Magisk） |

任一不符 → `post-fs-data.sh` 直接退出，**一个 ko 都不加载**。

同机型但系统版本不同 = **未验证**，内核代码布局可能已变。确实要在别的机器上试：

```bash
touch /data/adb/modules/Droidspaces/allow_any_device   # 跳过机型锁
touch /data/adb/modules/Droidspaces/allow_any_kernel   # 跳过内核锁
echo  <代号> >> /data/adb/modules/Droidspaces/allow_list # 追加白名单
```

> ⚠ 这三个"放开"文件**不要随包分发**。

---

## 4. 安全机制（防 bootloop）

1. 首次安装 / 升级后默认**关闭自启**（包内预置 `no_boot`）。
2. 机型 + 内核**双锁**，不符即退出。
3. **bootloop 守卫**：insmod 前落 `insmod.inflight`，成功即删；若某次开机崩在 insmod，
   下次开机检测到 → 生成 `blocked` 并跳过加载。
4. **存活守卫**：insmod 成功后留 `boot_pending`，`service.sh` 等 120 秒确认系统还活着
   才写 `.boot_ok`；下次开机若 `boot_pending` 还在、`.boot_ok` 不在 → 判定"加载后崩溃"，
   自动建 `blocked` 跳过。窗口可用 `alive_sec` 调整（默认 120，上限 900）。
5. `misc` 默认**只注册 devtmpfs 文件系统**，不起线程、不碰 dentry，崩不了。
6. `droid_lkm_pids` 是**独立模块**，分两层，都能单独 `rmmod`，也能和已加载的
   `droid_lkm_misc` 共存：
   - **显示层**：hook `cgroup_controllers_show` / `proc_cgroupstats_show` 两个
     打印函数，让 Droidspaces 的 `Process limit support` 检查项显示为通过。
   - **功能层**：挂出 `pids.max` / `pids.current` / `pids.stats`，并用 kprobe 在
     `cgroup_can_fork` 上让超限的 fork 返回 `-EAGAIN`，使 `--pids-limit` 真正生效。
   放 `skip_pids` 可让它不被加载。技术细节见
   [`docs/PIDS-ENFORCEMENT.md`](docs/PIDS-ENFORCEMENT.md)。
7. `droid_lkm_misc` 的 `release` 参数是双向的：
   `echo 1 > .../parameters/release` 放掉内部 devtmpfs mount（卸载前必须做，
   否则 `rmmod` 报 EBUSY）；`echo 0 > .../parameters/release` 把它装回去
   （放掉之后 devtmpfs 文件系统是被注销掉的，需要这条恢复）。

救援顺序：KernelSU 安全模式（开机按住音量下）→ 或删 `/data/adb/modules/Droidspaces`
→ 或删 `blocked` 后重启（会重试一次）。

---

## 5. 开关一览（模块目录下的文件）

| 文件 | 作用 |
| --- | --- |
| `no_boot` | 开机不自动加载（**本包默认存在**） |
| `skip_lkm` | 跳过 `droid_lkm`（Docker 靠它，别关） |
| `skip_vendor` | 跳过 vendor 兼容层 |
| `skip_misc` | 跳过 misc（失去 userns + devtmpfs） |
| `skip_pids` | 跳过 pids 上报模块（DS 的 Process limit 检查项会变回 ✗） |
| `skip_macvlan` | 跳过 macvlan |
| `skip_ip6nat` | 跳过 ip6table_nat |
| `skip_net` | 一次跳过上面两个网络模块 |
| `no_log` | 关闭日志记录 |
| `no_precheck` | 关闭加载前自检 |
| `delay` | 内容为秒数，开机延迟加载（上限 600） |
| `alive_sec` | 存活窗口秒数（默认 120，上限 900） |
| `blocked` | 存在则一律不加载（守卫触发时生成） |

---

## 6. 已知限制

- **`pids` 控制器是模拟实现**，不是内核原生 `CONFIG_CGROUP_PIDS`：
  - 通过写 `cgroup.procs` 迁移进容器的进程不立即计入 `pids.current`（真实控制器会计入），
    存在 1 个的偏差；
  - `--pids-limit` 建议 **≥ 256**（空跑容器自身约需 68 个进程，设 32 会饿死容器，
    表现为 `docker stop` 超时后被 SIGKILL）；
  - 换内核需重编；布局自校验失败时功能层自动退化成纯显示层（不崩，只是不限制）。
  完整说明见 [`docs/PIDS-ENFORCEMENT.md`](docs/PIDS-ENFORCEMENT.md#8-已知偏差与限制)。
- **macvlan 数据面不通**：本机 WiFi 驱动只接受一个 MAC，接口能建能删，
  但 TX 计数上涨、RX 恒为 0、ARP 永远 FAILED。要真用需 USB 有线网卡。
  host 网络模式下**不需要** macvlan。
- **KCFI 严格**：任何重编都必须用匹配的 DDK clang 19，用系统 clang 18 编的模块
  `insmod` 会直接关机。

---

## 7. 许可

本项目自有代码以 **GPL-2.0** 发布。引入的第三方源码（KallRecon、HooKern、KernCall、
Type_info、内核 macvlan / ip6table_nat 实现）各自保留原许可证，
详见 `THIRD-PARTY.md`。

`macvlan_core.c` 与 `ip6table_nat_core.c` 派生自 Linux 内核源码，
Copyright Patrick McHardy 等，SPDX GPL-2.0-or-later / GPL-2.0-only。
